import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // ✅ SIGN UP USER
  Future<String?> signUpUser({
    required String email,
    required String password,
    required String name,
    required String userType, // 'customer' or 'worker'
  }) async {
    try {
      UserCredential userCredential = await _auth
          .createUserWithEmailAndPassword(email: email, password: password);

      await _firestore.collection('users').doc(userCredential.user!.uid).set({
        'uid': userCredential.user!.uid,
        'email': email,
        'name': name,
        'userType': userType,
        'createdAt': FieldValue.serverTimestamp(),
      });

      return null; // Success
    } on FirebaseAuthException catch (e) {
      return e.message;
    } catch (_) {
      return 'An unexpected error occurred.';
    }
  }

  Future<UserCredential?> signInWithGoogle({required String userType}) async {
    try {
      final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();
      if (googleUser == null) return null;

      final GoogleSignInAuthentication googleAuth =
          await googleUser.authentication;

      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      final userCredential = await FirebaseAuth.instance.signInWithCredential(
        credential,
      );

      final user = userCredential.user;
      if (user != null) {
        final userDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .get();

        if (!userDoc.exists) {
          await FirebaseFirestore.instance
              .collection('users')
              .doc(user.uid)
              .set({
                'name': user.displayName ?? '',
                'email': user.email ?? '',
                'userType': userType,
                'createdAt': Timestamp.now(),
              });
        }
      }

      return userCredential;
    } catch (e) {
      print('Google sign-in failed: $e');
      return null;
    }
  }

  Future<String?> sendPasswordResetEmail(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
      return null; // success
    } catch (e) {
      return "Failed to send reset email. Please try again.";
    }
  }

  // ✅ LOGIN USER
  Future<String?> loginUser({
    required String email,
    required String password,
  }) async {
    try {
      await _auth.signInWithEmailAndPassword(email: email, password: password);
      return null; // Success
    } on FirebaseAuthException catch (e) {
      return e.message;
    } catch (_) {
      return 'An unexpected error occurred.';
    }
  }

  // ✅ LOGOUT USER
  Future<void> signOut() async {
    await _auth.signOut();
    // Optional: Clear local cache or shared preferences if added later
  }

  // ✅ GET CURRENT USER
  User? get currentUser => _auth.currentUser;

  // ✅ GET CURRENT USER TYPE
  Future<String?> getCurrentUserType() async {
    final user = _auth.currentUser;
    if (user == null) return null;

    final doc = await _firestore.collection('users').doc(user.uid).get();
    return doc.data()?['userType'] as String?;
  }

  // ✅ SAVE WORKER ONBOARDING DATA TO 'workers' COLLECTION
  // Future<String?> saveWorkerOnboardingData(
  //   Map<String, dynamic> workerData,
  // ) async {
  //   try {
  //     final user = _auth.currentUser;
  //     if (user == null) return "User not logged in";
  //     await _firestore.collection('workers').doc(user.uid).set({
  //       'uid': user.uid,
  //       'fullName': workerData['fullName'],
  //       'phone': workerData['phone'],
  //       'gender': workerData['gender'],
  //       'imagePicked': workerData['imagePicked'] ?? false,
  //       'skills': workerData['skills'] ?? [],
  //       'experienceLevel': workerData['experienceLevel'] ?? '',
  //       'paymentMethod': workerData['paymentMethod'] ?? '',
  //       'schedule': workerData['schedule'] ?? {},
  //       'primaryIdType': workerData['primaryIdType'] ?? '',
  //       'phoneNumber': workerData['phoneNumber'] ?? '',
  //       'consent': workerData['consent'] ?? false,
  //       'submittedAt': FieldValue.serverTimestamp(),
  //       'email':
  //           workerData['email'] ??
  //           FirebaseAuth.instance.currentUser?.email ??
  //           '',
  //       // Static defaults for tracking
  //       'averageRating': 0.0,
  //       'completedJobsCount': 0,
  //       'earnings': 0.0,
  //     });
  //     return null; // ✅ Success
  //   } catch (e) {
  //     print("Error saving worker data: $e");
  //     return "Something went wrong. Please try again.";
  //   }
  // }

  Future<String?> saveWorkerOnboardingData(
    Map<String, dynamic> workerData,
  ) async {
    try {
      final user = _auth.currentUser;
      if (user == null) return "User not logged in";

      // Ensure UID is added
      //workerData['uid'] = user.uid;
      workerData['uid'] = user.uid;
      workerData['name'] = workerData['fullName'] ?? 'Unnamed Worker';
      workerData['pricing'] = workerData['pricing'] ?? '₹300';
      workerData['averageRating'] = workerData['averageRating'] ?? 0.0;
      workerData['completedJobsCount'] = workerData['completedJobsCount'] ?? 0;
      workerData['earnings'] = workerData['earnings'] ?? 0.0;

      // ✅ Add fallback safety for location + address
      workerData['location'] =
          workerData['location'] ??
          const GeoPoint(0.0, 0.0); // Prevent null crash
      workerData['address'] = workerData['address'] ?? '';

      await _firestore
          .collection('workers')
          .doc(user.uid)
          //.set(workerData); // ✅ Saves full data, including location
          .set(
            workerData,
            SetOptions(merge: true),
          ); // ✅ preserves previous fields

      return null;
    } catch (e) {
      print("Error saving worker data: $e");
      return "Something went wrong. Please try again.";
    }
  }

  // ✅ OTP STUB – SEND
  Future<void> sendOtpToPhone(String phoneNumber) async {
    // Placeholder for future Firebase Phone Auth integration
    print("Sending OTP to $phoneNumber (stub)");
  }

  // ✅ OTP STUB – VERIFY
  Future<bool> verifyOtp(String otp) async {
    // Placeholder logic – replace with real Firebase verification
    return otp == '1234';
  }

  // ✅ GET CURRENT USER PROFILE
  Future<Map<String, dynamic>?> getUserProfile() async {
    final user = _auth.currentUser;
    if (user == null) return null;

    final doc = await _firestore.collection('users').doc(user.uid).get();
    return doc.data();
  }
}
