import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:google_sign_in/google_sign_in.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;

  // ✅ SIGN UP USER - FIXED VERSION
  Future<String?> signUpUser({
    required String email,
    required String password,
    required String name,
    required String userType,
    File? profileImage,
  }) async {
    try {
      print("DEBUG: Starting signUpUser for $userType: $email");

      // Step 1: Create Firebase Auth user
      UserCredential userCredential = await _auth
          .createUserWithEmailAndPassword(email: email, password: password);

      final user = userCredential.user;
      final uid = user?.uid;

      print("DEBUG: User created with UID = $uid");

      if (uid == null) {
        return "User UID is null after signup.";
      }

      // Add a small delay to ensure auth state is propagated
      await Future.delayed(const Duration(milliseconds: 500));

      // Step 2: Upload profile image if provided
      String? profileImageUrl;
      if (profileImage != null) {
        try {
          // Use appropriate path based on user type
          final storagePath = userType == 'worker'
              ? "worker_profile_images/$uid/profile.jpg"
              : "users/$uid/profile.jpg";

          print("DEBUG: Uploading to storage path: $storagePath");

          final imageRef = _storage.ref().child(storagePath);

          // Add metadata for better tracking
          final metadata = SettableMetadata(
            contentType: 'image/jpeg',
            customMetadata: {
              'uploadedBy': uid,
              'userType': userType,
              'uploadTime': DateTime.now().toIso8601String(),
            },
          );

          // Upload file
          final uploadTask = await imageRef.putFile(profileImage, metadata);

          // Get download URL
          profileImageUrl = await imageRef.getDownloadURL();

          print("✅ Image uploaded successfully: $profileImageUrl");
        } on FirebaseException catch (e) {
          print("❌ Storage error: ${e.code} - ${e.message}");
          // Don't fail entire signup if image upload fails
          // Continue without image
          profileImageUrl = null;
        } catch (e) {
          print("❌ Unexpected storage error: $e");
          profileImageUrl = null;
        }
      }

      // Step 3: Save user data in Firestore
      await _firestore.collection('users').doc(uid).set({
        'uid': uid,
        'email': email,
        'name': name,
        'userType': userType,
        'profileImage': profileImageUrl ?? '',
        'createdAt': FieldValue.serverTimestamp(),
      });

      print("✅ User data saved to Firestore");

      return null; // Success
    } on FirebaseAuthException catch (e) {
      print("❌ FirebaseAuth error: ${e.code} - ${e.message}");

      switch (e.code) {
        case 'weak-password':
          return 'Password should be at least 6 characters.';
        case 'email-already-in-use':
          return 'An account already exists with this email.';
        case 'invalid-email':
          return 'Please enter a valid email address.';
        case 'operation-not-allowed':
          return 'Email/password accounts are not enabled. Please contact support.';
        default:
          return e.message ?? 'Authentication failed. Please try again.';
      }
    } catch (e) {
      print("❌ Unexpected error during signUpUser: $e");
      return 'An unexpected error occurred: ${e.toString()}';
    }
  }

  // ✅ Google Sign-In
  Future<UserCredential?> signInWithGoogle({required String userType}) async {
    try {
      final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();
      if (googleUser == null) return null;

      final GoogleSignInAuthentication googleAuth =
          await googleUser.authentication;

      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      final userCredential = await FirebaseAuth.instance.signInWithCredential(
        credential,
      );

      final user = userCredential.user;
      if (user != null) {
        final userDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .get();

        if (!userDoc.exists) {
          await FirebaseFirestore.instance
              .collection('users')
              .doc(user.uid)
              .set({
                'name': user.displayName ?? '',
                'email': user.email ?? '',
                'userType': userType,
                'profileImage': user.photoURL ?? '',
                'createdAt': FieldValue.serverTimestamp(),
              });
        }
      }

      return userCredential;
    } catch (e) {
      print('Google sign-in failed: $e');
      return null;
    }
  }

  // ✅ Password Reset
  Future<String?> sendPasswordResetEmail(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
      return null; // success
    } on FirebaseAuthException catch (e) {
      return e.message ?? "Failed to send reset email.";
    } catch (e) {
      return "Failed to send reset email. Please try again.";
    }
  }

  // ✅ Login
  Future<String?> loginUser({
    required String email,
    required String password,
  }) async {
    try {
      await _auth.signInWithEmailAndPassword(email: email, password: password);
      return null; // Success
    } on FirebaseAuthException catch (e) {
      switch (e.code) {
        case 'user-not-found':
          return 'No account found with this email.';
        case 'wrong-password':
          return 'Incorrect password.';
        case 'invalid-email':
          return 'Invalid email address.';
        case 'user-disabled':
          return 'This account has been disabled.';
        default:
          return e.message ?? 'Login failed. Please try again.';
      }
    } catch (e) {
      return 'An unexpected error occurred. Please try again.';
    }
  }

  // ✅ Logout
  Future<void> signOut() async {
    await GoogleSignIn().signOut();
    await _auth.signOut();
  }

  // ✅ Get Current User
  User? get currentUser => _auth.currentUser;

  // ✅ Get Current User Type
  Future<String?> getCurrentUserType() async {
    final user = _auth.currentUser;
    if (user == null) return null;

    try {
      final doc = await _firestore.collection('users').doc(user.uid).get();
      return doc.data()?['userType'] as String?;
    } catch (e) {
      print("Error getting user type: $e");
      return null;
    }
  }

  // ✅ Save Worker Onboarding Data
  Future<String?> saveWorkerOnboardingData(
    Map<String, dynamic> workerData,
  ) async {
    try {
      final user = _auth.currentUser;
      if (user == null) return "User not logged in";

      // Ensure required fields
      workerData['uid'] = user.uid;
      workerData['name'] = workerData['fullName'] ?? 'Unnamed Worker';
      workerData['pricing'] = workerData['pricing'] ?? '₹300';
      workerData['averageRating'] = workerData['averageRating'] ?? 0.0;
      workerData['completedJobsCount'] = workerData['completedJobsCount'] ?? 0;
      workerData['earnings'] = workerData['earnings'] ?? 0.0;
      workerData['location'] =
          workerData['location'] ?? const GeoPoint(0.0, 0.0);
      workerData['address'] = workerData['address'] ?? '';
      workerData['updatedAt'] = FieldValue.serverTimestamp();

      await _firestore
          .collection('workers')
          .doc(user.uid)
          .set(workerData, SetOptions(merge: true));

      print("✅ Worker data saved successfully");
      return null; // Success
    } catch (e) {
      print("❌ Error saving worker data: $e");
      return "Failed to save worker data. Please try again.";
    }
  }

  // ✅ Get Current User Profile
  Future<Map<String, dynamic>?> getUserProfile() async {
    final user = _auth.currentUser;
    if (user == null) return null;

    try {
      final doc = await _firestore.collection('users').doc(user.uid).get();
      return doc.data();
    } catch (e) {
      print("Error getting user profile: $e");
      return null;
    }
  }

  // ✅ Check if email is already registered
  Future<bool> isEmailRegistered(String email) async {
    try {
      final methods = await _auth.fetchSignInMethodsForEmail(email);
      return methods.isNotEmpty;
    } catch (e) {
      print("Error checking email: $e");
      return false;
    }
  }
}
