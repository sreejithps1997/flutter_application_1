import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../../services/auth_service.dart';
import '../../models/worker_onboarding_data.dart';
import 'package:workable/screens/worker_signup/step1_profile_screen.dart';

class WorkerSignupScreen extends StatefulWidget {
  static const routeName = '/worker-signup';
  const WorkerSignupScreen({super.key});

  @override
  State<WorkerSignupScreen> createState() => _WorkerSignupScreenState();
}

class _WorkerSignupScreenState extends State<WorkerSignupScreen> {
  final _formKey = GlobalKey<FormState>();

  // Controllers
  final _fullNameController = TextEditingController();
  final _ageController = TextEditingController();
  final _phoneController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  final _authService = AuthService();
  final _picker = ImagePicker();

  // State flags
  String _selectedGender = 'Male';
  File? _profileImage;
  String _verificationId = '';
  String _enteredOtp = '';

  bool _obscurePassword = true;
  bool _isLoading = false;
  bool _otpSent = false;
  bool _isOtpSending = false;
  bool _isVerifyingOtp = false;
  bool _isPhoneVerified = false;

  // ======== TEST NUMBER CONFIG ========
  bool _isTestNumber(String phone) {
    const testNumbers = ['+919999999999', '+91123456']; // add more if needed
    return testNumbers.contains(phone);
  }

  // // ============ SIGN UP LOGIC ============
  // Future<void> _submitSignup() async {
  //   if (!_formKey.currentState!.validate()) return;
  //   if (!_isPhoneVerified) {
  //     _showSnackbar("Please verify your phone first");
  //     return;
  //   }

  //   setState(() => _isLoading = true);

  //   try {
  //     final result = await _authService.signUpUser(
  //       email: _emailController.text.trim(),
  //       password: _passwordController.text.trim(),
  //       name: _fullNameController.text.trim(),
  //       userType: 'worker',
  //     );

  //     final user = FirebaseAuth.instance.currentUser;
  //     final uid = user?.uid;
  //     if (uid == null) throw Exception("UID is null.");

  //     if (_profileImage == null)
  //       throw Exception("Please select a profile image.");

  //     final imageRef = FirebaseStorage.instance
  //         .ref()
  //         .child('worker_profile_images')
  //         .child(uid)
  //         .child('profile.jpg');

  //     await imageRef.putFile(_profileImage!);
  //     final imageUrl = await imageRef.getDownloadURL();

  //     final onboardingData = WorkerOnboardingData(
  //       uid: uid,
  //       fullName: _fullNameController.text.trim(),
  //       phone: _phoneController.text.trim(),
  //       phoneNumber: _phoneController.text.trim(),
  //       gender: _selectedGender,
  //       age: int.tryParse(_ageController.text.trim()) ?? 0,
  //       email: _emailController.text.trim(),
  //       consent: true,
  //       profileImageUrl: imageUrl,
  //     );

  //     // Save in Firestore
  //     await FirebaseFirestore.instance.collection('users').doc(uid).set({
  //       'uid': uid,
  //       'email': onboardingData.email,
  //       'role': 'worker',
  //       'createdAt': FieldValue.serverTimestamp(),
  //     });

  //     await FirebaseFirestore.instance
  //         .collection('workers')
  //         .doc(uid)
  //         .set(onboardingData.toMap());

  //     setState(() => _isLoading = false);

  //     ScaffoldMessenger.of(context).showSnackBar(
  //       const SnackBar(
  //         content: Text("Account created! Starting onboarding..."),
  //       ),
  //     );

  //     Navigator.pushReplacementNamed(
  //       context,
  //       Step1ProfileScreen.routeName,
  //       arguments: onboardingData,
  //     );
  //   } catch (e) {
  //     setState(() => _isLoading = false);
  //     _showErrorDialog(e.toString());
  //   }
  // }

  Future<void> _submitSignup() async {
    if (!_formKey.currentState!.validate()) return;
    if (!_isPhoneVerified) {
      _showSnackbar("Please verify your phone first");
      return;
    }
    if (_profileImage == null) {
      _showSnackbar("Please select a profile image.");
      return;
    }

    setState(() => _isLoading = true);

    try {
      // 1. First, create the user account in Firebase Authentication.
      final result = await _authService.signUpUser(
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
        name: _fullNameController.text.trim(),
        userType: 'worker',
      );

      // 2. Check if the authentication was successful and get the user.
      final user = FirebaseAuth.instance.currentUser;
      final uid = user?.uid;
      print("DEBUG: Current user = $user, UID = $uid");
      if (uid == null) {
        // If the user is null, something went wrong with signup.
        // Throw an exception to trigger the catch block.
        throw Exception("User UID is null after signup.");
      }

      // 3. ONLY NOW, after authentication is successful, proceed with the storage upload.
      final imageRef = FirebaseStorage.instance
          .ref()
          .child('worker_profile_images')
          .child(uid) // The authenticated user's ID
          .child('profile.jpg');

      await imageRef.putFile(_profileImage!);
      final imageUrl = await imageRef.getDownloadURL();

      // 4. Now save data to Firestore
      final onboardingData = WorkerOnboardingData(
        uid: uid,
        fullName: _fullNameController.text.trim(),
        phone: _phoneController.text.trim(),
        phoneNumber: _phoneController.text.trim(),
        gender: _selectedGender,
        age: int.tryParse(_ageController.text.trim()) ?? 0,
        email: _emailController.text.trim(),
        consent: true,
        profileImageUrl: imageUrl,
      );

      await FirebaseFirestore.instance.collection('users').doc(uid).set({
        'uid': uid,
        'email': onboardingData.email,
        'role': 'worker',
        'createdAt': FieldValue.serverTimestamp(),
      });

      await FirebaseFirestore.instance
          .collection('workers')
          .doc(uid)
          .set(onboardingData.toMap());

      setState(() => _isLoading = false);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Account created! Starting onboarding..."),
        ),
      );

      Navigator.pushReplacementNamed(
        context,
        Step1ProfileScreen.routeName,
        arguments: onboardingData,
      );
    } on FirebaseAuthException catch (e) {
      // Handle authentication-specific errors (e.g., email-already-in-use)
      setState(() => _isLoading = false);
      _showErrorDialog("Authentication Error: ${e.message}");
    } catch (e) {
      // Handle other errors (e.g., Firebase Storage errors)
      setState(() => _isLoading = false);
      _showErrorDialog("Error: ${e.toString()}");
    }
  }

  // ============ OTP VERIFICATION LOGIC ============
  Future<void> _sendOtp() async {
    final phone = '+91${_phoneController.text.trim()}';

    if (_phoneController.text.trim().length != 10) {
      _showSnackbar("Enter a valid 10-digit phone number");
      return;
    }

    setState(() {
      _otpSent = true;
      _isOtpSending = true;
      _isPhoneVerified = false;
    });

    if (_isTestNumber(phone)) {
      // Auto-verify test number
      await Future.delayed(const Duration(milliseconds: 500));
      setState(() {
        _isPhoneVerified = true;
        _isOtpSending = false;
        _otpSent = false;
      });
      _showSnackbar("Test number verified automatically!");
      return;
    }

    // Regular Firebase OTP flow
    await FirebaseAuth.instance.verifyPhoneNumber(
      phoneNumber: phone,
      timeout: const Duration(seconds: 60),
      verificationCompleted: (PhoneAuthCredential credential) async {
        setState(() {
          _isPhoneVerified = true;
          _isOtpSending = false;
        });
        _showSnackbar("Phone number verified automatically");
      },
      verificationFailed: (FirebaseAuthException e) {
        setState(() => _isOtpSending = false);
        _showSnackbar("OTP Failed: ${e.message}");
      },
      codeSent: (verificationId, _) {
        setState(() {
          _verificationId = verificationId;
          _isOtpSending = false;
        });
        _showSnackbar("OTP sent! Check your phone.");
      },
      codeAutoRetrievalTimeout: (verificationId) {
        _verificationId = verificationId;
        setState(() => _isOtpSending = false);
      },
    );
  }

  Future<void> _verifyOtpAndContinue() async {
    if (_enteredOtp.length != 6) {
      _showSnackbar("Enter the 6-digit OTP");
      return;
    }

    setState(() => _isVerifyingOtp = true);

    try {
      final credential = PhoneAuthProvider.credential(
        verificationId: _verificationId,
        smsCode: _enteredOtp.trim(),
      );

      setState(() {
        _isPhoneVerified = true;
        _isVerifyingOtp = false;
      });

      _showSnackbar("Phone number verified successfully!");
    } catch (e) {
      setState(() => _isVerifyingOtp = false);
      _showSnackbar("Invalid OTP: ${e.toString()}");
    }
  }

  // ============ UTILITY ============
  void _showSnackbar(String message) {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Signup Failed"),
        content: Text(message),
        actions: [
          TextButton(
            child: const Text("OK"),
            onPressed: () => Navigator.of(context).pop(),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _fullNameController.dispose();
    _ageController.dispose();
    _phoneController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  // ============ UI BUILD ============
  @override
  Widget build(BuildContext context) {
    final isTest = _isTestNumber('+91${_phoneController.text.trim()}');

    return Scaffold(
      appBar: AppBar(
        title: const Text("Worker Sign Up"),
        backgroundColor: Colors.deepPurple,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          child: ListView(
            children: [
              const Icon(Icons.engineering, size: 80, color: Colors.deepPurple),
              const SizedBox(height: 20),
              const Text(
                "Create your worker account",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 32),

              // Profile Image Picker
              GestureDetector(
                onTap: () async {
                  final picked = await ImagePicker().pickImage(
                    source: ImageSource.gallery,
                  );
                  if (picked != null)
                    setState(() => _profileImage = File(picked.path));
                },
                child: CircleAvatar(
                  radius: 70,
                  backgroundColor: Colors.grey[300],
                  backgroundImage: _profileImage != null
                      ? FileImage(_profileImage!)
                      : null,
                  child: _profileImage == null
                      ? const Icon(
                          Icons.camera_alt,
                          size: 40,
                          color: Colors.deepPurple,
                        )
                      : null,
                ),
              ),
              const SizedBox(height: 24),

              _buildTextField(
                controller: _fullNameController,
                label: "Full Name",
                icon: Icons.person,
              ),
              const SizedBox(height: 16),
              _buildTextField(
                controller: _ageController,
                label: "Age",
                icon: Icons.calendar_today,
                keyboardType: TextInputType.number,
                validator: (value) {
                  final age = int.tryParse(value ?? '');
                  if (value == null || value.isEmpty) return "Enter your age";
                  if (age == null || age < 18 || age > 70)
                    return "Age must be 18–70";
                  return null;
                },
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: _selectedGender,
                decoration: const InputDecoration(
                  labelText: "Gender",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.transgender),
                ),
                items: const [
                  DropdownMenuItem(value: 'Male', child: Text('Male')),
                  DropdownMenuItem(value: 'Female', child: Text('Female')),
                  DropdownMenuItem(value: 'Other', child: Text('Other')),
                ],
                onChanged: (val) =>
                    setState(() => _selectedGender = val ?? 'Male'),
              ),
              const SizedBox(height: 16),
              _buildTextField(
                controller: _phoneController,
                label: "Phone Number",
                icon: Icons.phone,
                keyboardType: TextInputType.phone,
                validator: (value) {
                  if (value == null || value.isEmpty)
                    return "Enter phone number";
                  if (!RegExp(r'^\d{10}$').hasMatch(value))
                    return "Invalid phone number";
                  return null;
                },
              ),
              const SizedBox(height: 8),
              ElevatedButton(
                onPressed: (_isOtpSending || _isPhoneVerified)
                    ? null
                    : _sendOtp,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.deepPurple,
                ),
                child: _isOtpSending
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                    : Text(isTest ? "Verify Test Number" : "Send OTP"),
              ),

              // OTP input only for real numbers
              if (_otpSent && !isTest) ...[
                const SizedBox(height: 12),
                _buildTextField(
                  label: "Enter OTP",
                  icon: Icons.lock,
                  keyboardType: TextInputType.number,
                  onChanged: (val) => _enteredOtp = val,
                ),
                const SizedBox(height: 8),
                _isVerifyingOtp
                    ? const CircularProgressIndicator()
                    : ElevatedButton(
                        onPressed: _verifyOtpAndContinue,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                        ),
                        child: const Text("Verify OTP"),
                      ),
              ],

              const SizedBox(height: 16),
              _buildTextField(
                controller: _emailController,
                label: "Email",
                icon: Icons.email,
                keyboardType: TextInputType.emailAddress,
                validator: (value) {
                  if (value == null || value.isEmpty) return 'Enter your email';
                  if (!RegExp(
                    r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$',
                  ).hasMatch(value))
                    return 'Enter a valid email';
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _passwordController,
                obscureText: _obscurePassword,
                decoration: InputDecoration(
                  labelText: "Password",
                  border: const OutlineInputBorder(),
                  prefixIcon: const Icon(Icons.lock),
                  suffixIcon: IconButton(
                    icon: Icon(
                      _obscurePassword
                          ? Icons.visibility
                          : Icons.visibility_off,
                    ),
                    onPressed: () =>
                        setState(() => _obscurePassword = !_obscurePassword),
                  ),
                ),
                validator: (value) {
                  if (value == null || value.length < 6)
                    return 'Minimum 6 characters';
                  if (!RegExp(r'\d').hasMatch(value))
                    return 'Must include a number';
                  if (!RegExp(r'[A-Z]').hasMatch(value))
                    return 'Must include uppercase';
                  return null;
                },
              ),
              const SizedBox(height: 30),
              _isLoading
                  ? const Center(child: CircularProgressIndicator())
                  : SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: (_isLoading || !_isPhoneVerified)
                            ? null
                            : _submitSignup,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.deepPurple,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                        ),
                        child: const Text(
                          "Sign Up",
                          style: TextStyle(fontSize: 16),
                        ),
                      ),
                    ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField({
    TextEditingController? controller,
    String? label,
    IconData? icon,
    TextInputType keyboardType = TextInputType.text,
    String? Function(String?)? validator,
    Function(String)? onChanged,
  }) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: icon != null ? Icon(icon) : null,
        border: const OutlineInputBorder(),
      ),
      keyboardType: keyboardType,
      validator: validator,
      onChanged: onChanged,
    );
  }
}
