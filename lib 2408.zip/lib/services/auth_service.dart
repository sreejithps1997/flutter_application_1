import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart'; // 👈 added
import 'package:google_sign_in/google_sign_in.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance; // 👈 added

  // ✅ SIGN UP USER
  Future<String?> signUpUser({
    required String email,
    required String password,
    required String name,
    required String userType, // 'customer' or 'worker'
    File? profileImage, // 👈 optional image parameter
  }) async {
    try {
      // Step 1: Create Firebase Auth user
      UserCredential userCredential = await _auth
          .createUserWithEmailAndPassword(email: email, password: password);

      final user = userCredential.user;
      final uid = user?.uid;

      print("DEBUG: Current user = $user, UID = $uid");

      if (uid == null) {
        return "User UID is null after signup.";
      }

      // Step 2: If profile image exists → Upload to Firebase Storage
      String? profileImageUrl;
      if (profileImage != null) {
        try {
          final imageRef = _storage.ref().child(
            "worker_profile_images/$uid/profile.jpg",
          );

          print(
            "DEBUG: Uploading profile image to path: worker_profile_images/$uid/profile.jpg",
          );

          await imageRef.putFile(profileImage);
          profileImageUrl = await imageRef.getDownloadURL();

          print("✅ Upload successful! Image URL = $profileImageUrl");
        } on FirebaseException catch (e) {
          print("❌ Firebase Storage error: ${e.code} - ${e.message}");
          return "Failed to upload profile image: ${e.message}";
        }
      }

      // Step 3: Save user data in Firestore
      await _firestore.collection('users').doc(uid).set({
        'uid': uid,
        'email': email,
        'name': name,
        'userType': userType,
        'profileImage': profileImageUrl ?? '', // 👈 Save URL if uploaded
        'createdAt': FieldValue.serverTimestamp(),
      });

      return null; // ✅ Success
    } on FirebaseAuthException catch (e) {
      print("❌ FirebaseAuth error: ${e.code} - ${e.message}");
      return e.message;
    } catch (e) {
      print("❌ Unexpected error during signUpUser: $e");
      return 'An unexpected error occurred.';
    }
  }

  // ✅ Google Sign-In
  Future<UserCredential?> signInWithGoogle({required String userType}) async {
    try {
      final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();
      if (googleUser == null) return null;

      final GoogleSignInAuthentication googleAuth =
          await googleUser.authentication;

      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      final userCredential = await FirebaseAuth.instance.signInWithCredential(
        credential,
      );

      final user = userCredential.user;
      if (user != null) {
        final userDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .get();

        if (!userDoc.exists) {
          await FirebaseFirestore.instance
              .collection('users')
              .doc(user.uid)
              .set({
                'name': user.displayName ?? '',
                'email': user.email ?? '',
                'userType': userType,
                'createdAt': Timestamp.now(),
              });
        }
      }

      return userCredential;
    } catch (e) {
      print('Google sign-in failed: $e');
      return null;
    }
  }

  // ✅ Password Reset
  Future<String?> sendPasswordResetEmail(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
      return null; // success
    } catch (e) {
      return "Failed to send reset email. Please try again.";
    }
  }

  // ✅ Login
  Future<String?> loginUser({
    required String email,
    required String password,
  }) async {
    try {
      await _auth.signInWithEmailAndPassword(email: email, password: password);
      return null; // Success
    } on FirebaseAuthException catch (e) {
      return e.message;
    } catch (_) {
      return 'An unexpected error occurred.';
    }
  }

  // ✅ Logout
  Future<void> signOut() async {
    await _auth.signOut();
  }

  // ✅ Get Current User
  User? get currentUser => _auth.currentUser;

  // ✅ Get Current User Type
  Future<String?> getCurrentUserType() async {
    final user = _auth.currentUser;
    if (user == null) return null;

    final doc = await _firestore.collection('users').doc(user.uid).get();
    return doc.data()?['userType'] as String?;
  }

  // ✅ Save Worker Onboarding Data
  Future<String?> saveWorkerOnboardingData(
    Map<String, dynamic> workerData,
  ) async {
    try {
      final user = _auth.currentUser;
      if (user == null) return "User not logged in";

      workerData['uid'] = user.uid;
      workerData['name'] = workerData['fullName'] ?? 'Unnamed Worker';
      workerData['pricing'] = workerData['pricing'] ?? '₹300';
      workerData['averageRating'] = workerData['averageRating'] ?? 0.0;
      workerData['completedJobsCount'] = workerData['completedJobsCount'] ?? 0;
      workerData['earnings'] = workerData['earnings'] ?? 0.0;
      workerData['location'] =
          workerData['location'] ?? const GeoPoint(0.0, 0.0);
      workerData['address'] = workerData['address'] ?? '';

      await _firestore
          .collection('workers')
          .doc(user.uid)
          .set(workerData, SetOptions(merge: true));

      return null;
    } catch (e) {
      print("Error saving worker data: $e");
      return "Something went wrong. Please try again.";
    }
  }

  // ✅ OTP STUB – SEND
  Future<void> sendOtpToPhone(String phoneNumber) async {
    print("Sending OTP to $phoneNumber (stub)");
  }

  // ✅ OTP STUB – VERIFY
  Future<bool> verifyOtp(String otp) async {
    return otp == '1234';
  }

  // ✅ Get Current User Profile
  Future<Map<String, dynamic>?> getUserProfile() async {
    final user = _auth.currentUser;
    if (user == null) return null;

    final doc = await _firestore.collection('users').doc(user.uid).get();
    return doc.data();
  }
}
